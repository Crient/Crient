# Install on Crient GitHub profile

GitHub connector returned 403 (not authorized to write), so upload these files using GitHub web or `git`.

## Fastest: Git on a laptop

```bash
git clone https://github.com/Crient/Crient.git
cd Crient
# Copy README.md and the entire assets/ folder from this package into this folder.
git add README.md assets/
git commit -m "feat: launch pixel playground GitHub profile"
git push origin main
```

GitHub renders profile README.md in Crient/Crient automatically. Your current README can be recovered from the previous git commit. Refresh https://github.com/Crient after push.

The original resume and social links are preserved. The portfolio button points to the GitHub repository because the interactive portfolio has not been verified as public/deployed yet; replace it with the live URL once published. The activity chart depends on a third-party service, and may be unavailable temporarily.
